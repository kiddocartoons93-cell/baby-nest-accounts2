# Daily Expense — Offline Android App

## Features
- Offline-first Android app; no internet permission and no account required.
- Expenses in Bangladeshi Taka (৳), with date, category, subcategory and note.
- Learns exact amount-to-category choices on this phone. Example: after saving ৳50 as Groceries, later entries of ৳50 suggest Groceries. Suggestions can be changed.
- Categories: Food & Dining; Transportation; Household & Groceries; Personal Care & Health; Shopping; Fixed Bills; Others.
- Monthly fixed bills: rent, electricity, gas, water, internet, mobile, monthly EMI, bank loan repayment and other fixed bills.
- Daily fixed-bill share = total monthly fixed bills / number of calendar days in the current month.
- Today/month totals, monthly category report, PDF report export and JSON backup.
- Data is stored in Android WebView local storage on the device.

## Build APK using GitHub (no computer build tools required)
1. Sign in to GitHub in your phone browser or app and create a **new public or private repository** named `daily-expense`.
2. Upload the contents of this ZIP into the repository (upload the files and folders, not the ZIP file itself). Make sure `.github/workflows/build-apk.yml` is included.
3. Open the repository's **Actions** tab. Select **Build Daily Expense APK** and tap **Run workflow**. If prompted, enable Actions.
4. Wait for the workflow to finish successfully. Open that completed run and find **Artifacts** at the bottom.
5. Download `Daily-Expense-APK`, extract the downloaded ZIP, then install `app-debug.apk` on your Android phone. Allow installation from that source if Android asks.

If GitHub's mobile interface hides file upload, open the repository in Chrome and enable **Desktop site**.

## Notes
- This is a debug APK for personal installation, not a Play Store release.
- Keep regular JSON backups from Reports > Backup data. Clearing app storage or uninstalling the app can erase local records.
- Amount suggestions are learned from amounts you have previously categorized; the app does not guess a category from the amount alone.

## Modern UI and animation upgrade
- Animated splash screen and smooth card/page transitions.
- Premium purple/blue gradient styling and glass-like cards.
- Light/dark theme toggle, saved on device.
- Animated monthly category progress bars.


## Modern v4 additions
- Custom purple wallet-and-growth launcher icon for Android (legacy density icons plus adaptive icon).
- Animated wallet splash mark, page transitions, and count-up dashboard totals.
- Light/dark theme, gradient controls, and visual save confirmation. Vibration feedback is disabled.


## Local user account (v5 update)
- First launch displays a Create Account / Sign In screen.
- Create one local account with a display name, username and password (minimum 6 characters).
- Passwords are salted and hashed with PBKDF2 on Android and stored in private app preferences; plaintext passwords are not saved.
- Sign in is required to open the expense manager. Log out returns to the sign-in screen.
- This is an offline, single-device account. It does not provide cloud sync, email recovery, or multi-device access.
- Uninstalling/clearing app data may remove the local account and expenses. Keep backups.

\n## v7 visual category picker update
- Replaced large Android native category/subcategory dropdown dialogs with illustrated in-page category cards and subcategory chips.
- Added category-specific emoji illustrations, color accents, selected states and touch animations.
- Retains the same saved category/subcategory values and learned amount suggestions.

## v8 custom categories
- Removed all preloaded category and subcategory choices.
- Users create their own categories and subcategories from the Add Expense page.
- Custom categories are saved locally and included in JSON backups.
- Existing expense history is retained; new expenses require a custom category and subcategory.
