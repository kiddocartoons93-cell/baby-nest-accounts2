package com.personal.dailyexpense;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.graphics.Color;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class MainActivity extends Activity {
    private SharedPreferences authPrefs;
    private WebView appWebView;
    private static final int ITERATIONS = 120000;
    private static final int KEY_LENGTH = 256;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(40, 20, 110));
        getWindow().setNavigationBarColor(Color.rgb(40, 20, 110));
        authPrefs = getSharedPreferences("daily_expense_auth", MODE_PRIVATE);
        WebView web = new WebView(this);
        appWebView = web;
        web.setBackgroundColor(Color.rgb(243, 244, 255));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public boolean hasAccount() {
                return authPrefs.contains("password_hash");
            }
            @JavascriptInterface public boolean hasSession() {
                return authPrefs.getBoolean("signed_in", false);
            }
            @JavascriptInterface public String getUsername() {
                return authPrefs.getString("username", "");
            }
            @JavascriptInterface public String getDisplayName() {
                return authPrefs.getString("display_name", "");
            }
            @JavascriptInterface public String createAccount(String displayName, String username, String password) {
                if (hasAccount()) return "An account already exists on this device. Please sign in.";
                try {
                    byte[] salt = new byte[16];
                    new SecureRandom().nextBytes(salt);
                    String hash = hashPassword(password, salt);
                    authPrefs.edit()
                        .putString("display_name", displayName.trim())
                        .putString("username", username.trim())
                        .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                        .putString("password_hash", hash)
                        .putBoolean("signed_in", false)
                        .apply();
                    return "OK";
                } catch (Exception e) { return "Could not create account. Please try again."; }
            }
            @JavascriptInterface public String signIn(String username, String password) {
                try {
                    if (!hasAccount()) return "No account found on this device.";
                    if (!authPrefs.getString("username", "").equals(username.trim())) return "INVALID";
                    byte[] salt = Base64.decode(authPrefs.getString("salt", ""), Base64.NO_WRAP);
                    String candidate = hashPassword(password, salt);
                    String saved = authPrefs.getString("password_hash", "");
                    if (!MessageDigest.isEqual(candidate.getBytes("UTF-8"), saved.getBytes("UTF-8"))) return "INVALID";
                    authPrefs.edit().putBoolean("signed_in", true).apply();
                    return "OK";
                } catch (Exception e) { return "INVALID"; }
            }
            @JavascriptInterface public void signOut() {
                authPrefs.edit().putBoolean("signed_in", false).apply();
            }
            @JavascriptInterface public void printHtml(String html) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    WebView printView = new WebView(MainActivity.this);
                    printView.loadDataWithBaseURL(null, html, "text/HTML", "UTF-8", null);
                    printView.setWebViewClient(new WebViewClient() {
                        @Override public void onPageFinished(WebView view, String url) {
                            PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                            String jobName = "Daily Expense Report";
                            printManager.print(jobName, view.createPrintDocumentAdapter(jobName),
                                new PrintAttributes.Builder()
                                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                    .setResolution(new PrintAttributes.Resolution("pdf", "pdf", 300, 300))
                                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                    .build());
                        }
                    });
                });
            }
        }, "AndroidAuth");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private String hashPassword(String password, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LENGTH);
        try {
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            return Base64.encodeToString(factory.generateSecret(spec).getEncoded(), Base64.NO_WRAP);
        } finally { spec.clearPassword(); }
    }

    @Override public void onBackPressed() {
        if (appWebView != null) {
            appWebView.evaluateJavascript("handleAndroidBack()", value -> {
                if ("false".equals(value)) MainActivity.super.onBackPressed();
            });
        } else { super.onBackPressed(); }
    }
}
