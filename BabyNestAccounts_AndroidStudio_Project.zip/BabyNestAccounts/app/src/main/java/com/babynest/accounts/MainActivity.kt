package com.babynest.accounts

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val NAVY = 0xFF172C46.toInt()
private const val PINK = 0xFFD88D9A.toInt()
private const val PALE = 0xFFF7F2F0.toInt()
private const val INK = 0xFF263445.toInt()

class LedgerDb(ctx: android.content.Context) : SQLiteOpenHelper(ctx, "baby_nest_ledger.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE entries(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kind TEXT NOT NULL, party TEXT NOT NULL, amount REAL NOT NULL,
            note TEXT, created_at TEXT NOT NULL)""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun add(kind: String, party: String, amount: Double, note: String) {
        val v = ContentValues().apply {
            put("kind", kind); put("party", party); put("amount", amount)
            put("note", note); put("created_at", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()))
        }
        writableDatabase.insert("entries", null, v)
    }
    fun totals(kind: String): Double {
        readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM entries WHERE kind=?", arrayOf(kind)).use {
            return if (it.moveToFirst()) it.getDouble(0) else 0.0
        }
    }
    fun rows(filter: String? = null): List<Entry> {
        val out = mutableListOf<Entry>()
        val sql = if (filter == null) "SELECT id,kind,party,amount,note,created_at FROM entries ORDER BY id DESC"
                  else "SELECT id,kind,party,amount,note,created_at FROM entries WHERE kind=? ORDER BY id DESC"
        readableDatabase.rawQuery(sql, if (filter == null) null else arrayOf(filter)).use { c ->
            while (c.moveToNext()) out.add(Entry(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3),c.getString(4) ?: "",c.getString(5)))
        }
        return out
    }
    fun partyBalance(party: String, customer: Boolean): Double {
        val positive = if (customer) "SALE" else "VENDOR_BILL"
        val negative = if (customer) "CUSTOMER_PAYMENT" else "VENDOR_PAYMENT"
        readableDatabase.rawQuery(
            "SELECT COALESCE(SUM(CASE WHEN kind=? THEN amount WHEN kind=? THEN -amount ELSE 0 END),0) FROM entries WHERE party=?",
            arrayOf(positive, negative, party)
        ).use { return if (it.moveToFirst()) it.getDouble(0) else 0.0 }
    }
}
data class Entry(val id: Long, val kind: String, val party: String, val amount: Double, val note: String, val date: String)

class MainActivity : Activity() {
    private lateinit var db: LedgerDb
    private lateinit var content: LinearLayout
    private var page = "Dashboard"
    private val money = { v: Double -> "৳ " + String.format(Locale.US, "%,.2f", v) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = LedgerDb(this)
        show()
    }
    private fun lp(w: Int = -1, h: Int = -2) = LinearLayout.LayoutParams(w,h)
    private fun text(s: String, size: Float = 15f, color: Int = INK, bold: Boolean = false): TextView =
        TextView(this).apply { text=s; textSize=size; setTextColor(color); if(bold) setTypeface(null, Typeface.BOLD); setPadding(0,6,0,6) }
    private fun button(s: String, action: () -> Unit): Button = Button(this).apply {
        text=s; isAllCaps=false; setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(NAVY); setOnClickListener { action() }
    }
    private fun show() {
        val outer = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(PALE) }
        val header = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,18,20,14); setBackgroundColor(NAVY) }
        header.addView(text("BABY NEST",25f,0xFFFFFFFF.toInt(),true))
        header.addView(text("Accounts & Payment Manager",13f,0xFFDCE5EF.toInt()))
        outer.addView(header)
        val nav = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setPadding(4,4,4,4); setBackgroundColor(0xFFE9E2E0.toInt()) }
        listOf("Dashboard","Customers","Vendors","History").forEach { item ->
            nav.addView(Button(this).apply {
                text=item; isAllCaps=false; textSize=11f; setPadding(2,0,2,0)
                setTextColor(if(page==item) PINK else NAVY); setBackgroundColor(0xFFE9E2E0.toInt())
                layoutParams=LinearLayout.LayoutParams(0,-2,1f)
                setOnClickListener { page=item; show() }
            })
        }
        outer.addView(nav)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,14,18,24) }
        scroll.addView(content); outer.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(outer)
        when(page) {
            "Dashboard" -> dashboard()
            "Customers" -> parties(true)
            "Vendors" -> parties(false)
            else -> history()
        }
    }
    private fun card(label: String, value: Double, color: Int = INK) {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(14,10,14,10); setBackgroundColor(0xFFFFFFFF.toInt()) }
        box.addView(text(label,13f,0xFF667789.toInt()))
        box.addView(text(money(value),21f,color,true))
        val p=lp(); p.setMargins(0,0,0,10); content.addView(box,p)
    }
    private fun dashboard() {
        content.addView(text("Overview",20f,NAVY,true))
        val sales=db.totals("SALE")
        val received=db.totals("CUSTOMER_PAYMENT")
        val bills=db.totals("VENDOR_BILL")
        val paid=db.totals("VENDOR_PAYMENT")
        card("Total sales",sales)
        card("Customer payments received",received,0xFF287A58.toInt())
        card("Customer due",sales-received,0xFFC07824.toInt())
        card("Vendor payments",paid)
        card("Vendor outstanding",bills-paid,0xFFC07824.toInt())
        content.addView(text("Quick actions",18f,NAVY,true))
        listOf(
            "Record sale / customer due" to { entryDialog("SALE") },
            "Receive customer payment" to { entryDialog("CUSTOMER_PAYMENT") },
            "Record vendor bill" to { entryDialog("VENDOR_BILL") },
            "Pay vendor" to { entryDialog("VENDOR_PAYMENT") }
        ).forEach { (label, act) -> content.addView(button(label,act),lp().apply { setMargins(0,4,0,4) }) }
        content.addView(text("Recent activity",18f,NAVY,true))
        db.rows().take(5).forEach { entryRow(it) }
        content.addView(text("Amounts are stored locally on this device. Set up Firebase to enable cloud backup (see README).",12f,0xFF667789.toInt()))
    }
    private fun parties(customer: Boolean) {
        val title = if(customer) "Customer accounts" else "Vendor accounts"
        content.addView(text(title,20f,NAVY,true))
        content.addView(text(if(customer) "Add sales to create due; record received payments to reduce due." else "Add vendor bills to create outstanding balance; record payments to reduce it.",13f))
        content.addView(button(if(customer) "＋ Record customer sale" else "＋ Record vendor bill") { entryDialog(if(customer) "SALE" else "VENDOR_BILL") })
        content.addView(button(if(customer) "＋ Receive customer payment" else "＋ Pay vendor") { entryDialog(if(customer) "CUSTOMER_PAYMENT" else "VENDOR_PAYMENT") })
        val map = linkedMapOf<String,Double>()
        db.rows().forEach { map[it.party] = db.partyBalance(it.party,customer) }
        if(map.isEmpty()) content.addView(text("No accounts yet. Add your first transaction.",14f))
        map.forEach { (name,balance) ->
            val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(12,8,12,8); setBackgroundColor(0xFFFFFFFF.toInt()) }
            box.addView(text(name,16f,NAVY,true))
            box.addView(text((if(customer) "Customer due: " else "Vendor outstanding: ")+money(balance),14f,if(balance>0) 0xFFC07824.toInt() else 0xFF287A58.toInt()))
            val p=lp(); p.setMargins(0,8,0,0); content.addView(box,p)
        }
    }
    private fun history() {
        content.addView(text("Transaction history",20f,NAVY,true))
        val options=arrayOf("All","Sales","Customer received","Vendor bills","Vendor payments")
        val keys=arrayOf("","SALE","CUSTOMER_PAYMENT","VENDOR_BILL","VENDOR_PAYMENT")
        val spinner=Spinner(this)
        spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,options)
        content.addView(spinner)
        val list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        content.addView(list)
        fun refresh() {
            list.removeAllViews()
            db.rows(keys[spinner.selectedItemPosition].ifEmpty { null }).forEach { e ->
                val v=text("${e.date}  •  ${e.party}\n${e.kind.replace('_',' ')}  —  ${money(e.amount)}${if(e.note.isNotBlank()) "\n${e.note}" else ""}",14f)
                v.setPadding(10,10,10,10); v.setBackgroundColor(0xFFFFFFFF.toInt())
                list.addView(v,lp().apply { setMargins(0,5,0,0) })
            }
        }
        spinner.onItemSelectedListener=object: AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { refresh() }
        }
        refresh()
        content.addView(button("＋ Add transaction") { chooseEntry() })
    }
    private fun entryRow(e: Entry) {
        content.addView(text("${e.date} • ${e.party} • ${e.kind.replace('_',' ')} • ${money(e.amount)}",13f))
    }
    private fun chooseEntry() {
        val labels=arrayOf("Sale / customer due","Customer payment received","Vendor bill","Vendor payment")
        val keys=arrayOf("SALE","CUSTOMER_PAYMENT","VENDOR_BILL","VENDOR_PAYMENT")
        AlertDialog.Builder(this).setTitle("Add transaction").setItems(labels) { _, which -> entryDialog(keys[which]) }.show()
    }
    private fun entryDialog(kind: String) {
        val customer=kind=="SALE" || kind=="CUSTOMER_PAYMENT"
        val title=when(kind) {
            "SALE" -> "Record sale"
            "CUSTOMER_PAYMENT" -> "Receive customer payment"
            "VENDOR_BILL" -> "Record vendor bill"
            else -> "Pay vendor"
        }
        val wrap=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,8,22,0) }
        val party=EditText(this).apply { hint=if(customer) "Customer name" else "Vendor name"; singleLine=true }
        val amount=EditText(this).apply { hint="Amount (BDT)"; inputType=8194 }
        val note=EditText(this).apply { hint="Note / reference (optional)" }
        wrap.addView(party); wrap.addView(amount); wrap.addView(note)
        AlertDialog.Builder(this).setTitle(title).setView(wrap)
            .setNegativeButton("Cancel",null)
            .setPositiveButton("Save",null).create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(-1).setOnClickListener {
                        val name=party.text.toString().trim()
                        val value=amount.text.toString().toDoubleOrNull()
                        if(name.isEmpty() || value==null || value<=0) {
                            Toast.makeText(this,"Enter a name and a valid amount.",Toast.LENGTH_LONG).show()
                        } else {
                            db.add(kind,name,value,note.text.toString().trim())
                            dialog.dismiss(); show()
                            Toast.makeText(this,"Transaction saved.",Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                dialog.show()
            }
    }
}
