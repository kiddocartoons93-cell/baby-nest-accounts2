# BABY NEST Accounts — Android Studio project

This is a native Android starter app for English-language shop bookkeeping. It stores transactions in a local SQLite database and calculates customer due and vendor outstanding balances.

## Included
- Dashboard: total sales, customer receipts, customer due, vendor payments and vendor outstanding
- Customer ledger: sales and payments by customer
- Vendor ledger: bills and payments by vendor
- Transaction history with category filter
- BDT (৳) amounts and transaction dates
- Offline-first local storage

## Build the APK
1. Install **Android Studio** on a computer.
2. Open this `BabyNestAccounts` folder in Android Studio.
3. Allow Gradle sync and install the Android SDK platform requested by the project (API 35).
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

This environment did not have the Android SDK or Gradle installed, so an APK could not be compiled here. The ZIP contains the Android Studio source project, not an installable APK.

## Cloud backup setup (required before cloud sync is available)
The current app is offline-first. Cloud backup is **not yet connected** because it requires a Firebase project owned by you.
1. Create a Firebase project at https://console.firebase.google.com/
2. Add an Android app with package name `com.babynest.accounts`.
3. Download `google-services.json` and place it in the `app/` folder.
4. Enable Firebase Authentication and Cloud Firestore (or Firebase Realtime Database).
5. Add the Google Services and Firebase dependencies, then implement authenticated backup/restore and conflict handling before using cloud sync.

Do not treat Android device backup as a substitute for a verified cloud backup. Keep regular exports until cloud backup is tested.

## Important accounting notes
- A `SALE` increases customer due.
- A `CUSTOMER_PAYMENT` reduces customer due.
- A `VENDOR_BILL` increases vendor outstanding.
- A `VENDOR_PAYMENT` reduces vendor outstanding.
- Enter consistent customer/vendor names to keep each ledger grouped correctly.
- This starter version does not yet include edit/delete, authentication, multi-user access, PDF receipts, Excel export, or live cloud synchronization.
