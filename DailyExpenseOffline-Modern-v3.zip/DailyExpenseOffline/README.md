# Daily Expense — Offline Android App

## Features
- Offline-first Android app; no internet permission and no account required.
- Expenses in Bangladeshi Taka (৳), with date, category, subcategory and note.
- Learns exact amount-to-category choices on this phone. Example: after saving ৳50 as Groceries, later entries of ৳50 suggest Groceries. Suggestions can be changed.
- Categories: Food & Dining; Transportation; Household & Groceries; Personal Care & Health; Shopping; Fixed Bills; Others.
- Monthly fixed bills: rent, electricity, gas, water, internet, mobile, monthly EMI, bank loan repayment and other fixed bills.
- Daily fixed-bill share = total monthly fixed bills / number of calendar days in the current month.
- Today/month totals, monthly category report, PDF report export and JSON backup.
- Data is stored in Android WebView local storage on the device.

## Build APK using GitHub (no computer build tools required)
1. Sign in to GitHub in your phone browser or app and create a **new public or private repository** named `daily-expense`.
2. Upload the contents of this ZIP into the repository (upload the files and folders, not the ZIP file itself). Make sure `.github/workflows/build-apk.yml` is included.
3. Open the repository's **Actions** tab. Select **Build Daily Expense APK** and tap **Run workflow**. If prompted, enable Actions.
4. Wait for the workflow to finish successfully. Open that completed run and find **Artifacts** at the bottom.
5. Download `Daily-Expense-APK`, extract the downloaded ZIP, then install `app-debug.apk` on your Android phone. Allow installation from that source if Android asks.

If GitHub's mobile interface hides file upload, open the repository in Chrome and enable **Desktop site**.

## Notes
- This is a debug APK for personal installation, not a Play Store release.
- Keep regular JSON backups from Reports > Backup data. Clearing app storage or uninstalling the app can erase local records.
- Amount suggestions are learned from amounts you have previously categorized; the app does not guess a category from the amount alone.

## Modern UI and animation upgrade
- Animated splash screen and smooth card/page transitions.
- Premium purple/blue gradient styling and glass-like cards.
- Light/dark theme toggle, saved on device.
- Animated monthly category progress bars.
